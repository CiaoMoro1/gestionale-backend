from flask import Blueprint, request, jsonify, send_file
from app.supabase_client import supabase
import uuid
import io
import zipfile

bp = Blueprint('notecredito_amazon_reso', __name__)

BUCKET = "notecredito"  # Bucket separato per le note di credito

# 1. ENDPOINT UPLOAD RETURN_ITEMS.CSV
# 1. ENDPOINT UPLOAD RETURN_ITEMS + RETURN_SUMMARY
@bp.route('/api/notecredito_amazon_reso/upload', methods=['POST'])
def upload_notecredito_amazon_reso():
    if 'return_items' not in request.files:
        return jsonify({'error': 'File return_items mancante'}), 400

    items_file = request.files['return_items']
    items_path = f"return_items/{uuid.uuid4()}_{items_file.filename}"
    items_bytes = items_file.read()
    res1 = supabase.storage.from_(BUCKET).upload(items_path, items_bytes, {"content-type": "text/csv"})
    if hasattr(res1, 'error') and res1.error:
        return jsonify({'error': 'Errore upload return_items su storage'}), 500

    summary_path = None
    if 'return_summary' in request.files and request.files['return_summary'].filename:
        summary_file = request.files['return_summary']
        # può essere xls o xlsx
        ct = "application/vnd.ms-excel" if summary_file.filename.lower().endswith(".xls") else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        summary_path = f"return_summary/{uuid.uuid4()}_{summary_file.filename}"
        summary_bytes = summary_file.read()
        res2 = supabase.storage.from_(BUCKET).upload(summary_path, summary_bytes, {"content-type": ct})
        if hasattr(res2, 'error') and res2.error:
            return jsonify({'error': 'Errore upload return_summary su storage'}), 500

    job_id = str(uuid.uuid4())
    job_payload = {
        "storage_path": f"{BUCKET}/{items_path}",
        "summary_path": f"{BUCKET}/{summary_path}" if summary_path else None
    }
    supabase.table("jobs").insert({
        "id": job_id,
        "type": "genera_notecredito_amazon_reso",
        "payload": job_payload,
        "status": "pending"
    }).execute()

    return jsonify({"job_id": job_id, "status": "pending"})



# app/routes/notecredito_amazon_reso.py

@bp.route('/api/notecredito_amazon_reso/list', methods=['GET'])
def lista_notecredito_amazon_reso():
    try:
        query = supabase.table("notecredito_amazon_reso").select("*")

        po = request.args.get("po")
        vret = request.args.get("vret")
        stato = request.args.get("stato")
        job_id = request.args.get("job_id")
        date_from = request.args.get("date_from")  # YYYY-MM-DD
        date_to = request.args.get("date_to")      # YYYY-MM-DD

        if po:
            query = query.eq("po", po)
        if vret:
            query = query.eq("vret", vret)
        if stato:
            query = query.eq("stato", stato)
        if job_id:
            query = query.eq("job_id", job_id)
        if date_from:
            query = query.gte("data_nota", date_from)
        if date_to:
            query = query.lte("data_nota", date_to)

        # mostra le più recenti prima
        res = query.order("created_at", desc=True).limit(200).execute()
        return jsonify(res.data)
    except Exception as e:
        print(f"ERRORE su /api/notecredito_amazon_reso/list: {e}")
        return jsonify({"error": "Errore nel recupero note credito", "details": str(e)}), 500



# 3. DOWNLOAD SINGOLA NOTA DI CREDITO
@bp.route('/api/notecredito_amazon_reso/download/<int:nota_id>', methods=['GET'])
def download_notecredito_amazon_reso(nota_id):
    try:
        nota = supabase.table("notecredito_amazon_reso").select("*").eq("id", nota_id).single().execute().data
        if not nota:
            return jsonify({"error": "Nota di credito non trovata"}), 404
        xml_url = nota.get("xml_url")
        if not xml_url:
            return jsonify({"error": "Nota senza XML"}), 404

        bucket, file_path = xml_url.split('/', 1)
        file_resp = supabase.storage.from_(bucket).download(file_path)
        if not file_resp:
            return jsonify({"error": "File non trovato"}), 404

        return send_file(
            io.BytesIO(file_resp),
            download_name=f"NotaCredito_{nota['numero_nota']}_{nota['po']}_{nota['data_nota'].replace('-', '')}.xml",
            as_attachment=True,
            mimetype="application/xml"
        )
    except Exception as e:
        print(f"ERRORE su /api/notecredito_amazon_reso/download: {e}")
        return jsonify({"error": "Errore durante il download", "details": str(e)}), 500


# 4. DETTAGLIO SINGOLA NOTA (opzionale)
@bp.route('/api/notecredito_amazon_reso/<int:nota_id>', methods=['GET'])
def dettaglio_notecredito_amazon_reso(nota_id):
    try:
        nota = supabase.table("notecredito_amazon_reso").select("*").eq("id", nota_id).single().execute().data
        if not nota:
            return jsonify({"error": "Nota di credito non trovata"}), 404
        return jsonify(nota)
    except Exception as e:
        print(f"ERRORE su /api/notecredito_amazon_reso/{nota_id}: {e}")
        return jsonify({"error": "Errore nel recupero della nota", "details": str(e)}), 500


# 5. DOWNLOAD ZIP MASSIVO
@bp.route('/api/notecredito_amazon_reso/download_zip', methods=['POST'])
def download_zip_notecredito_amazon_reso():
    """
    Riceve lista di ID nota di credito via POST JSON: {"ids": [1,2,3]}
    Restituisce un unico ZIP con tutti gli XML delle note richieste.
    """
    try:
        ids = request.json.get('ids')
        if not ids or not isinstance(ids, list):
            return jsonify({"error": "IDs non forniti"}), 400

        # Scarica tutte le note richieste
        note = supabase.table("notecredito_amazon_reso").select("*").in_("id", ids).execute().data
        if not note:
            return jsonify({"error": "Nessuna nota trovata"}), 404

        memory_file = io.BytesIO()
        with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for n in note:
                xml_url = n.get("xml_url")
                if not xml_url:
                    continue
                bucket, file_path = xml_url.split('/', 1)
                file_resp = supabase.storage.from_(bucket).download(file_path)
                if not file_resp:
                    continue
                filename = f"NotaCredito_{n['numero_nota']}_{n['po']}_{n['data_nota'].replace('-', '')}.xml"
                zipf.writestr(filename, file_resp)
        memory_file.seek(0)
        return send_file(
            memory_file,
            download_name="NoteCredito_AmazonReso.zip",
            as_attachment=True,
            mimetype="application/zip"
        )

    except Exception as e:
        print(f"ERRORE su /api/notecredito_amazon_reso/download_zip: {e}")
        return jsonify({"error": "Errore durante il download ZIP", "details": str(e)}), 500
