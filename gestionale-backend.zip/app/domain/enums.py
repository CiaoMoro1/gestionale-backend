from enum import StrEnum
class StatoPrelievo(StrEnum):
    MANCA="manca"; PARZIALE="parziale"; COMPLETO="completo"; IN_VERIFICA="in verifica"
